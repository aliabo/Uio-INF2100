package parser;

public abstract class Operator extends PascalSyntax {

	Operator(int lnum){
		super(lnum);
	}
}
